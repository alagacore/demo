# Alaga Master Portal

A standalone React + Vite project, ready to deploy to Vercel as its own site or as
a new version of the existing `alaga-master-portal` project.

## What's inside

- `src/App.jsx` — the entire application (all screens, the onboarding wizard, the
  landing chooser). This is the same file shared in chat as `alaga-mockup.jsx`.
- `src/main.jsx` — mounts the app, and includes a small polyfill (see below).
- Standard Vite + React scaffolding (`index.html`, `vite.config.js`, `package.json`).

## The one thing that's different from the in-chat version

The app was originally built as a Claude.ai artifact, which provides a built-in
`window.storage` API for saving data (subsidy edits, tours pipeline changes,
expenses, accessibility settings, etc.). That API only exists inside Claude's
artifact sandbox — a normal browser doesn't have it.

`src/main.jsx` polyfills `window.storage` with an equivalent backed by the
browser's `localStorage`, using the exact same method signatures
(`get`/`set`/`delete`/`list`). Nothing in `App.jsx` had to change. This means
data now persists **per browser, on that device** — there's no shared backend,
so two people opening the deployed link won't see each other's changes. That's
fine for a demo/pilot; if this becomes a real multi-user product later, that
polyfill is the piece to replace with real API calls to a backend.

## Deploy to Vercel

**Option A — Vercel CLI (fastest, no GitHub needed):**
```bash
npm install -g vercel
cd alaga-vercel
vercel
```
Follow the prompts (link to your Vercel account, accept the detected Vite
settings). It'll give you a preview URL immediately; run `vercel --prod` to
publish it live.

**Option B — GitHub + Vercel dashboard (recommended if you want ongoing deploys):**
1. Push this folder to a new GitHub repo (or a branch/folder in your existing
   `alaga-master-portal` repo).
2. In the Vercel dashboard, "Add New Project" → import that repo.
3. Vercel auto-detects Vite from `vercel.json` — no config needed. Build command
   `npm run build`, output directory `dist`.
4. Every future push to the connected branch redeploys automatically.

**If you want this to replace your existing `alaga-master-portal` deployment**
specifically: point Vercel's existing project at this code (via Option B, same
repo/branch it's already watching) rather than creating a second project, so the
URL stays the same.

## Local development

```bash
npm install
npm run dev       # local dev server with hot reload
npm run build     # production build → dist/
npm run preview   # serve the production build locally to sanity-check it
```

## Verified before hand-off

This was built and tested, not just assumed to work:
- `npm run build` completes cleanly.
- The production build was served locally and click-tested end to end
  (landing → demo workspace → Families → edit → save → reload → data
  persists via the localStorage polyfill → parent portal → FSA/HSA section).
